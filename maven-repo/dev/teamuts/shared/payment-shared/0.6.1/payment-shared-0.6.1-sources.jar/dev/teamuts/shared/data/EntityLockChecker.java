package dev.teamuts.shared.data;

import dev.teamuts.shared.domain.model.BaseIdentifiableModel;
import jakarta.persistence.EntityManager;
import jakarta.persistence.LockModeType;
import java.util.EnumSet;
import java.util.Objects;

/** Checks pessimistic locks known to the current JPA persistence context. */
public class EntityLockChecker {
  private final EntityManager entityManager;

  public EntityLockChecker(EntityManager entityManager) {
    this.entityManager = Objects.requireNonNull(entityManager);
  }

  private static final EnumSet<LockModeType> PESSIMISTIC_LOCK_MODES =
      EnumSet.of(
          LockModeType.PESSIMISTIC_READ,
          LockModeType.PESSIMISTIC_WRITE,
          LockModeType.PESSIMISTIC_FORCE_INCREMENT);

  /**
   * Returns whether the current transaction holds a JPA pessimistic lock on the model's row.
   *
   * <p>The entity class must map the supplied model, using the same primary key. This method may
   * load the entity, but does not request a lock. It cannot detect locks acquired through native
   * SQL, implicit database locks, or locks held by another transaction. A false result means JPA
   * does not report a pessimistic lock; it does not prove the database row is unlocked.
   *
   * @param model domain model with a persisted ID
   * @param entityClass the jpa entity class that maps the model
   */
  public boolean isLocked(BaseIdentifiableModel<?> model, Class<?> entityClass) {
    Objects.requireNonNull(model);
    Objects.requireNonNull(entityClass);

    if (!entityManager.isJoinedToTransaction()) {
      return false;
    }

    model.checkPersisted();

    Object entity = entityManager.find(entityClass, model.getId());

    if (entity == null) {
      return false;
    }

    return PESSIMISTIC_LOCK_MODES.contains(entityManager.getLockMode(entity));
  }

  /** Requires a pessimistic lock reported by JPA. */
  public void requireLocked(BaseIdentifiableModel<?> model, Class<?> entityClass) {
    if (!isLocked(model, entityClass)) {
      throw PersistenceException.notAcquiredLock(model, entityClass);
    }
  }
}
